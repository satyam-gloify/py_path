# number of runs by each batsman
runs = records_df.groupby(['Batsman_Name'])['Runs'].count().reset_index()
runs