# get all the records of the data
records_data = sheet_instance.get_all_records()

# view the data
records_data